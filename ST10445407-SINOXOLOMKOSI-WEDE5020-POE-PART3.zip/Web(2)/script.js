// JavaScript to toggle the navbar color on scroll
window.addEventListener('scroll' , function() {
    const navbar = document.getElementById ('navbar');

    // Check scroll position and apply the "scrolled" class
    if (this.window.scrollY>50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    
    }
});


